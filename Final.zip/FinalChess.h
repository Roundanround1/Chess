#pragma once

class Chess {    
    public:
    char piece;
    char team;
    int points;
};